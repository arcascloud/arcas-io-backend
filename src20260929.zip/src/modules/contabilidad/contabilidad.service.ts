import { Injectable, NotFoundException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, FindOptionsWhere, ObjectLiteral, Not } from 'typeorm';
import { FechaSistemaService } from '../../shared/fecha-sistema.service';
import { RolesService } from '../users/roles.service';
import { Coctacontables } from './entities/coctacontables.entity';
import { Tcogrupocontable } from './entities/tcogrupocontable.entity';
import { Tcoplantillapdamae } from './entities/tcoplantillapdamae.entity';
import { Tcoplantillapdadet } from './entities/tcoplantillapdadet.entity';
import { Coctasaldos } from './entities/coctasaldos.entity';
import { Cocierrectable } from './entities/cocierrectable.entity';
import { Cocierredet } from './entities/cocierredet.entity';
import { Tcorepliquidez } from './entities/tcorepliquidez.entity';
import { Ttipofactordecambios } from './entities/ttipofactordecambios.entity';
import { Tcoplantillabalancesmae } from './entities/tcoplantillabalancesmae.entity';
import { Tcoplantillabalancesdet } from './entities/tcoplantillabalancesdet.entity';
import { Tcorepdiarios } from './entities/tcorepdiarios.entity';
import { Tcorepbalances } from './entities/tcorepbalances.entity';
import { Coperiodoctable } from './entities/coperiodoctable.entity';
import { Copdamae } from './entities/copdamae.entity';
import { Copdadet } from './entities/copdadet.entity';
import { Coctamov } from './entities/coctamov.entity';
import { Tconivelcta } from './entities/tconivelcta.entity';
import { Tconaturalezacta } from './entities/tconaturalezacta.entity';
import { Tcoimpuestovecinal } from './entities/tcoimpuestovecinal.entity';
import { TCoTipoDocumentoFiscal } from './entities/tcotipodocumentofiscal.entity';
import { Tempresas } from '../companies/entities/empresa.entity';
import { Tcocarteras } from './entities/tcocarteras.entity';
import { Tcoisr } from './entities/tcoisr.entity';
import {
  CreateCoctacontablesDto, UpdateCoctacontablesDto,
  CreateCopdamaeDto, UpdateCopdamaeDto,
  CreateCopdadetDto, UpdateCopdadetDto,
  ReporteBalanceDinamicoDto,
  CalcularSaldosCtaDto,
} from './dto/contabilidad.dto';

@Injectable()
export class ContabilidadService {
  constructor(
    @InjectRepository(Coctacontables) private readonly ctacontablesRepo: Repository<Coctacontables>,
    @InjectRepository(Tcogrupocontable) private readonly grupocontableRepo: Repository<Tcogrupocontable>,
    @InjectRepository(Tcoplantillapdamae) private readonly plantillapdamaeRepo: Repository<Tcoplantillapdamae>,
    @InjectRepository(Tcoplantillapdadet) private readonly plantillapdadetRepo: Repository<Tcoplantillapdadet>,
    @InjectRepository(Coctasaldos) private readonly saldosctaRepo: Repository<Coctasaldos>,
    @InjectRepository(Cocierrectable) private readonly cierrectableRepo: Repository<Cocierrectable>,
    @InjectRepository(Cocierredet) private readonly cierredetRepo: Repository<Cocierredet>,
    @InjectRepository(Tcorepliquidez) private readonly repliquidezRepo: Repository<Tcorepliquidez>,
    @InjectRepository(Ttipofactordecambios) private readonly factordecambioRepo: Repository<Ttipofactordecambios>,
    @InjectRepository(Tcoplantillabalancesmae) private readonly plantillabalancesmaeRepo: Repository<Tcoplantillabalancesmae>,
    @InjectRepository(Tcoplantillabalancesdet) private readonly plantillabalancesdetRepo: Repository<Tcoplantillabalancesdet>,
    @InjectRepository(Tcorepdiarios) private readonly repdiariosRepo: Repository<Tcorepdiarios>,
    @InjectRepository(Tcorepbalances) private readonly repbalancesRepo: Repository<Tcorepbalances>,
    @InjectRepository(Coperiodoctable) private readonly periodoctableRepo: Repository<Coperiodoctable>,
    @InjectRepository(Copdamae) private readonly copdamaeRepo: Repository<Copdamae>,
    @InjectRepository(Copdadet) private readonly copdadetRepo: Repository<Copdadet>,
    @InjectRepository(Coctamov) private readonly movctaRepo: Repository<Coctamov>,
    @InjectRepository(Tconivelcta) private readonly nivelctaRepo: Repository<Tconivelcta>,
    @InjectRepository(Tconaturalezacta) private readonly naturalezactaRepo: Repository<Tconaturalezacta>,
    @InjectRepository(Tcoimpuestovecinal) private readonly impuestovecinalRepo: Repository<Tcoimpuestovecinal>,
    @InjectRepository(TCoTipoDocumentoFiscal) private readonly tipoDocFiscalRepo: Repository<TCoTipoDocumentoFiscal>,
    @InjectRepository(Tempresas) private readonly empresasRepo: Repository<Tempresas>,
    @InjectRepository(Tcocarteras) private readonly carterasRepo: Repository<Tcocarteras>,
    @InjectRepository(Tcoisr) private readonly isrRepo: Repository<Tcoisr>,
    private readonly fechaSistema: FechaSistemaService,
    private readonly rolesService: RolesService,
  ) {}

  private async findAllByEmpresa<T extends ObjectLiteral>(repo: Repository<T>, empresaId: number) {
    return repo.find({
      where: { empresaId } as unknown as FindOptionsWhere<T>,
    });
  }

  private async findOneById<T extends ObjectLiteral>(
    repo: Repository<T>,
    idField: string,
    id: number | string,
    empresaId: number,
    entityName: string,
  ) {
    const where = { [idField]: id, empresaId } as unknown as FindOptionsWhere<T>;
    const found = await repo.findOne({ where });
    if (!found) throw new NotFoundException(`${entityName} ${id} no encontrado`);
    return found;
  }

  private async findOneByIdNoEmpresa<T extends ObjectLiteral>(
    repo: Repository<T>,
    idField: string,
    id: number | string,
    entityName: string,
  ) {
    const where = { [idField]: id } as unknown as FindOptionsWhere<T>;
    const found = await repo.findOne({ where });
    if (!found) throw new NotFoundException(`${entityName} ${id} no encontrado`);
    return found;
  }

  private async createEntity<T extends ObjectLiteral>(
    repo: Repository<T>,
    dto: any,
    currentUser: string,
  ) {
    const entity = repo.create({
      ...dto,
      usuarioCreated: currentUser,
    });
    return repo.save(entity);
  }

  private async updateEntity<T extends ObjectLiteral>(
    repo: Repository<T>,
    idField: string,
    id: number | string,
    empresaId: number,
    dto: any,
    currentUser: string,
    entityName: string,
  ) {
    const entity = await this.findOneById(repo, idField, id, empresaId, entityName);
    Object.assign(entity, dto, {
      usuarioUpdated: currentUser,
      fechaUpdated: await this.fechaSistema.getFecha(empresaId),
    });
    return repo.save(entity);
  }

  private async updateEntityNoEmpresa<T extends ObjectLiteral>(
    repo: Repository<T>,
    idField: string,
    id: number | string,
    dto: any,
    currentUser: string,
    entityName: string,
  ) {
    const entity = await this.findOneByIdNoEmpresa(repo, idField, id, entityName);
    Object.assign(entity, dto, {
      usuarioUpdated: currentUser,
      fechaUpdated: new Date(),
    });
    return repo.save(entity);
  }

  private async softDelete<T extends ObjectLiteral>(
    repo: Repository<T>,
    idField: string,
    id: number | string,
    empresaId: number,
    entityName: string,
  ) {
    const entity = await this.findOneById(repo, idField, id, empresaId, entityName);
    Object.assign(entity, {
      sn_activo: 'N',
      fechaUpdated: await this.fechaSistema.getFecha(empresaId),
    });
    return repo.save(entity);
  }

  private async softDeleteNoEmpresa<T extends ObjectLiteral>(
    repo: Repository<T>,
    idField: string,
    id: number | string,
    entityName: string,
  ) {
    const entity = await this.findOneByIdNoEmpresa(repo, idField, id, entityName);
    Object.assign(entity, {
      sn_activo: 'N',
      fechaUpdated: new Date(),
    });
    return repo.save(entity);
  }

  async findAllCtacontables(empresaId: number) {
    const cuentas = await this.findAllByEmpresa(this.ctacontablesRepo, empresaId);
    // sn_protegida = la cuenta ya registra historial (movimiento/cierre) → edición restringida
    const conHistorial = await this.cuentasConHistorial(empresaId);
    return cuentas.map((c) => ({ ...c, sn_protegida: conHistorial.has(c.ctacontable) }));
  }

  async findCtacontable(cuentacontablesId: number, empresaId: number) {
    const cuenta = await this.findOneById(this.ctacontablesRepo, 'cuentacontablesId', cuentacontablesId, empresaId, 'Cuenta Contable');
    const conHistorial = await this.cuentasConHistorial(empresaId);
    return { ...cuenta, sn_protegida: conHistorial.has((cuenta as Coctacontables).ctacontable) };
  }

  async createCtacontable(dto: CreateCoctacontablesDto, currentUser: string) {
    await this.validarDuplicadosCtacontable(dto.ctacontable, dto.descripcion, dto.empresaId);
    await this.validarMayorExistente(dto.ctacontable, dto.nivel, dto.padre, dto.empresaId);
    const result = await this.createEntity(this.ctacontablesRepo, dto, currentUser);
    await this.recalcularOrdenCtacontables(dto.empresaId);
    return result;
  }

  async updateCtacontable(cuentacontablesId: number, empresaId: number, dto: UpdateCoctacontablesDto, currentUser: string) {
    // Cuenta actual (necesaria para validar protección de sn_operable / historial)
    const cuentaActual = await this.findOneById(this.ctacontablesRepo, 'cuentacontablesId', cuentacontablesId, empresaId, 'Cuenta Contable') as Coctacontables;
    await this.validarProteccionCuenta(cuentaActual, dto, currentUser, empresaId);

    await this.validarDuplicadosCtacontable(dto.ctacontable, dto.descripcion, empresaId, cuentacontablesId);
    // Para update, necesitamos leer la entidad actual si no viene nivel/padre en el dto
    const actual = dto.nivel != null || dto.padre != null || dto.ctacontable != null
      ? { nivel: dto.nivel, padre: dto.padre, ctacontable: dto.ctacontable }
      : await this.findOneById(this.ctacontablesRepo, 'cuentacontablesId', cuentacontablesId, empresaId, 'Cuenta Contable');
    await this.validarMayorExistente(actual.ctacontable, actual.nivel, actual.padre, empresaId);
    const result = await this.updateEntity(this.ctacontablesRepo, 'cuentacontablesId', cuentacontablesId, empresaId, dto, currentUser, 'Cuenta Contable');
    await this.recalcularOrdenCtacontables(empresaId);
    return result;
  }

  // ========== Protección de cuentas contables (sn_operable / historial) ==========

  /**
   * Determina si la cuenta ya registra historial en:
   * coctamov (movimientos), coctasaldos (saldos), copdadet (partidas), cocierredet (cierre contable).
   */
  private async tieneHistorialCuenta(ctacontable: string, empresaId: number): Promise<boolean> {
    const existe = async (repo: Repository<ObjectLiteral>): Promise<boolean> => {
      const n = await repo.createQueryBuilder('t')
        .where('t.ctacontable = :cta', { cta: ctacontable })
        .andWhere('t.empresaId = :empresaId', { empresaId })
        .getCount();
      return n > 0;
    };
    if (await existe(this.movctaRepo)) return true;
    if (await existe(this.saldosctaRepo)) return true;
    if (await existe(this.copdadetRepo)) return true;
    return existe(this.cierredetRepo);
  }

  /** Códigos de cuentas (distinct) con historial de movimiento/cierre para la empresa */
  private async cuentasConHistorial(empresaId: number): Promise<Set<string>> {
    const distinct = async (repo: Repository<ObjectLiteral>): Promise<string[]> => {
      const rows = await repo.createQueryBuilder('t')
        .select('DISTINCT t.ctacontable', 'ctacontable')
        .where('t.empresaId = :empresaId', { empresaId })
        .getRawMany<{ ctacontable: string }>();
      return rows.map((r) => r.ctacontable).filter((c) => !!c);
    };
    const [mov, sal, det, cie] = await Promise.all([
      distinct(this.movctaRepo),
      distinct(this.saldosctaRepo),
      distinct(this.copdadetRepo),
      distinct(this.cierredetRepo),
    ]);
    return new Set([...mov, ...sal, ...det, ...cie]);
  }

  /**
   * Reglas de protección al editar una cuenta contable:
   * - R1: cuenta con historial → solo roles admin/supervisor/contador pueden modificarla (cualquier campo).
   * - R2: cuenta operable ('S') con historial → NO puede convertirse en cuenta Mayor ('N') para nadie.
   * - R3: habilitar una cuenta como operable ('S') → solo roles admin/supervisor/contador.
   * Si no hay historial ni cambio de sn_operable, no se consultan roles (ruta rápida).
   */
  private async validarProteccionCuenta(
    actual: Coctacontables,
    dto: UpdateCoctacontablesDto,
    currentUser: string,
    empresaId: number,
  ): Promise<void> {
    const cambioOperable = dto.sn_operable != null && dto.sn_operable !== actual.sn_operable;
    const historial = await this.tieneHistorialCuenta(actual.ctacontable, empresaId);

    if (!historial && !cambioOperable) return;

    const privilegiado = await this.rolesService.esPrivilegiadoContabilidad(currentUser, empresaId);

    if (historial && !privilegiado) {
      throw new ForbiddenException(
        `La cuenta "${actual.ctacontable}" ya tiene historial de movimiento/cierre contable. ` +
        'Solo Contador, Supervisor o Administrador pueden modificarla.',
      );
    }
    if (historial && actual.sn_operable === 'S' && dto.sn_operable === 'N') {
      throw new ForbiddenException(
        `La cuenta "${actual.ctacontable}" es operable y ya registra historial de movimiento/cierre. ` +
        'No puede convertirse en cuenta Mayor.',
      );
    }
    if (cambioOperable && dto.sn_operable === 'S' && !privilegiado) {
      throw new ForbiddenException(
        'Solo Contador, Supervisor o Administrador pueden habilitar una cuenta como operable (Diario).',
      );
    }
  }

  /** True si la cuenta tiene historial y el usuario NO es admin/supervisor/contador */
  private async cuentaProtegidaParaUsuario(cuenta: Coctacontables, empresaId: number, currentUser?: string): Promise<boolean> {
    if (!currentUser) return false;
    const historial = await this.tieneHistorialCuenta(cuenta.ctacontable, empresaId);
    if (!historial) return false;
    return !(await this.rolesService.esPrivilegiadoContabilidad(currentUser, empresaId));
  }

  /**
   * Valida que no existan cuentas contables duplicadas por ctacontable o descripcion
   * dentro de la misma empresa. Al actualizar, excluye el registro actual.
   */
  private async validarDuplicadosCtacontable(
    ctacontable: string | undefined,
    descripcion: string | undefined,
    empresaId: number,
    excludeId?: number,
  ): Promise<void> {
    if (!ctacontable && !descripcion) return;

    const conditions: string[] = [];
    const params: any = { empresaId };

    if (ctacontable) {
      conditions.push('cta.ctacontable = :ctacontable');
      params.ctacontable = ctacontable;
    }
    if (descripcion) {
      conditions.push('LOWER(cta.descripcion) = :descripcion');
      params.descripcion = descripcion.toLowerCase();
    }

    const qb = this.ctacontablesRepo.createQueryBuilder('cta')
      .where('cta.empresaId = :empresaId', { empresaId })
      .andWhere(`(${conditions.join(' OR ')})`, params);

    if (excludeId) {
      qb.andWhere('cta.cuentacontablesId != :excludeId', { excludeId });
    }

    const duplicada = await qb.getOne();
    if (duplicada) {
      if (ctacontable && duplicada.ctacontable === ctacontable) {
        throw new BadRequestException(`La cuenta contable "${ctacontable}" ya existe`);
      }
      throw new BadRequestException(`Ya existe una cuenta con la descripción "${descripcion}"`);
    }
  }

  /**
   * Valida que para cuentas de nivel > 1 exista una cuenta de mayor
   * cuyo ctacontable coincida con el patrón del prefijo (antes del último guión).
   * Ej: nivel 4 con codigo '1110-002-0002' → debe existir '1110-002' (nivel 3).
   */
  private async validarMayorExistente(
    ctacontable: string | undefined,
    nivel: number | undefined,
    padre: string | undefined | null,
    empresaId: number,
  ): Promise<void> {
    // Solo validar si nivel > 1
    if (!nivel || nivel <= 1) return;
    if (!ctacontable) return;

    // Determinar el código del padre esperado
    const partes = ctacontable.split('-');
    if (partes.length < 2) return;
    const padreEsperado = partes.slice(0, -1).join('-');

    // Buscar si existe esa cuenta de mayor en la empresa
    const mayorExiste = await this.ctacontablesRepo.findOne({
      where: {
        ctacontable: padreEsperado,
        empresaId,
      } as unknown as FindOptionsWhere<Coctacontables>,
    });

    if (!mayorExiste) {
      const nivelPadre = nivel - 1;
      throw new BadRequestException(
        `No existe cuenta de mayor "${padreEsperado}" (nivel ${nivelPadre}). ` +
        `Debe crear primero la cuenta de nivel ${nivelPadre} antes de registrar cuentas de nivel ${nivel}.`
      );
    }
  }

  /**
   * Recalcula zorden de TODAS las cuentas contables de la empresa
   * basado en ROW_NUMBER() OVER (ORDER BY ctacontable).
   * Esto garantiza que el orden visual siempre sea secuencial
   * sin huecos, independientemente de Inserts/Updates/Deletes.
   */
  private async recalcularOrdenCtacontables(empresaId: number): Promise<void> {
    await this.ctacontablesRepo.query(`
      UPDATE coctacontables c
      INNER JOIN (
        SELECT cuentacontablesId,
               ROW_NUMBER() OVER (ORDER BY ctacontable) AS nuevoOrden
        FROM coctacontables
        WHERE empresaId = ?
      ) ranked ON c.cuentacontablesId = ranked.cuentacontablesId
      SET c.zorden = ranked.nuevoOrden
    `, [empresaId]);
  }

  async removeCtacontable(cuentacontablesId: number, empresaId: number, currentUser?: string) {
    // Cuenta con historial solo puede eliminarla admin/supervisor/contador
    const cuenta = await this.findOneById(this.ctacontablesRepo, 'cuentacontablesId', cuentacontablesId, empresaId, 'Cuenta Contable') as Coctacontables;
    if (await this.cuentaProtegidaParaUsuario(cuenta, empresaId, currentUser)) {
      throw new ForbiddenException(
        `La cuenta "${cuenta.ctacontable}" ya tiene historial de movimiento/cierre contable. ` +
        'Solo Contador, Supervisor o Administrador pueden eliminarla.',
      );
    }
    const result = await this.softDelete(this.ctacontablesRepo, 'cuentacontablesId', cuentacontablesId, empresaId, 'Cuenta Contable');
    await this.recalcularOrdenCtacontables(empresaId);
    return result;
  }

  async findAllGrupocontable(empresaId: number) {
    return this.grupocontableRepo.find({
      where: { empresaId, sn_activo: 'S' } as unknown as FindOptionsWhere<Tcogrupocontable>,
    });
  }

  async findGrupocontable(tcogrupocontableId: number, empresaId: number) {
    return this.findOneById(this.grupocontableRepo, 'tcogrupocontableId', tcogrupocontableId, empresaId, 'Grupo Contable');
  }

  async createGrupocontable(dto: any, currentUser: string) {
    return this.createEntity(this.grupocontableRepo, dto, currentUser);
  }

  async updateGrupocontable(tcogrupocontableId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.grupocontableRepo, 'tcogrupocontableId', tcogrupocontableId, empresaId, dto, currentUser, 'Grupo Contable');
  }

  async removeGrupocontable(tcogrupocontableId: number, empresaId: number) {
    return this.softDelete(this.grupocontableRepo, 'tcogrupocontableId', tcogrupocontableId, empresaId, 'Grupo Contable');
  }

  async findAllPlantillapdamae(empresaId: number) {
    return this.findAllByEmpresa(this.plantillapdamaeRepo, empresaId);
  }

  async findPlantillapdamae(tcoplantillapdamaeId: number, empresaId: number) {
    return this.findOneById(this.plantillapdamaeRepo, 'tcoplantillapdamaeId', tcoplantillapdamaeId, empresaId, 'Plantilla PDA Mae');
  }

  async createPlantillapdamae(dto: any, currentUser: string) {
    return this.createEntity(this.plantillapdamaeRepo, dto, currentUser);
  }

  async updatePlantillapdamae(tcoplantillapdamaeId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.plantillapdamaeRepo, 'tcoplantillapdamaeId', tcoplantillapdamaeId, empresaId, dto, currentUser, 'Plantilla PDA Mae');
  }

  async removePlantillapdamae(tcoplantillapdamaeId: number, empresaId: number) {
    return this.softDelete(this.plantillapdamaeRepo, 'tcoplantillapdamaeId', tcoplantillapdamaeId, empresaId, 'Plantilla PDA Mae');
  }

  async findAllPlantillapdadet(empresaId: number, tcoplantillapdamaeId?: number) {
    if (tcoplantillapdamaeId) {
      return this.plantillapdadetRepo.find({
        where: { empresaId, tcoplantillapdamaeId, sn_activo: 'S' } as any,
        order: { nrofila: 'ASC' },
      });
    }
    return this.plantillapdadetRepo.find({
      where: { empresaId, sn_activo: 'S' } as any,
    });
  }

  async findPlantillapdadet(tcoplantillapdadetId: number, empresaId: number) {
    return this.findOneById(this.plantillapdadetRepo, 'tcoplantillapdadetId', tcoplantillapdadetId, empresaId, 'Plantilla PDA Det');
  }

  async createPlantillapdadet(dto: any, currentUser: string) {
    await this.validarCtaUnicaPlantillaDet(dto?.tcoplantillapdamaeId, dto?.ctacontable);
    return this.createEntity(this.plantillapdadetRepo, dto, currentUser);
  }

  async updatePlantillapdadet(tcoplantillapdadetId: number, empresaId: number, dto: any, currentUser: string) {
    // Resuelve mae/cta actuales si el PUT es parcial
    const actual = await this.findOneById(this.plantillapdadetRepo, 'tcoplantillapdadetId', tcoplantillapdadetId, empresaId, 'Plantilla PDA Det');
    await this.validarCtaUnicaPlantillaDet(
      dto?.tcoplantillapdamaeId ?? actual.tcoplantillapdamaeId,
      dto?.ctacontable ?? actual.ctacontable,
      tcoplantillapdadetId,
    );
    return this.updateEntity(this.plantillapdadetRepo, 'tcoplantillapdadetId', tcoplantillapdadetId, empresaId, dto, currentUser, 'Plantilla PDA Det');
  }

  async removePlantillapdadet(tcoplantillapdadetId: number, empresaId: number) {
    return this.softDelete(this.plantillapdadetRepo, 'tcoplantillapdadetId', tcoplantillapdadetId, empresaId, 'Plantilla PDA Det');
  }

  /**
   * Valida que una cuenta contable NO se repita en el detalle de la misma plantilla PDA.
   * Regla de negocio: cada cuenta aparece una sola vez en el detalle de una plantilla.
   */
  private async validarCtaUnicaPlantillaDet(
    tcoplantillapdamaeId: number,
    ctacontable: string,
    excluirId?: number,
  ): Promise<void> {
    const maeId = Number(tcoplantillapdamaeId);
    const cta = (ctacontable ?? '').trim();
    if (!maeId || !cta) return;

    const filas = await this.plantillapdadetRepo.find({
      where: { tcoplantillapdamaeId: maeId, ctacontable: cta, sn_activo: 'S' } as any,
    });

    const duplicada = filas.find((f) => f.tcoplantillapdadetId !== excluirId);
    if (duplicada) {
      throw new BadRequestException(
        `La cuenta contable "${cta}" ya está ingresada en el detalle de la plantilla. Solo puede registrarse una vez.`,
      );
    }
  }

  async findAllSaldoscta(empresaId: number) {
    return this.findAllByEmpresa(this.saldosctaRepo, empresaId);
  }

  async findSaldoscta(cosaldosctaId: number, empresaId: number) {
    return this.findOneById(this.saldosctaRepo, 'cosaldosctaId', cosaldosctaId, empresaId, 'Saldo Cuenta');
  }

  /**
   * Estado de cuenta por partida de una cuenta contable (estilo libro diario).
   * Devuelve los movimientos de copdadet agrupados por nropartida en orden
   * descendente, más la descripción de la cuenta y los totales para el
   * encabezado/pie del reporte.
   *
   * Reglas del formato (validadas contra la expectativa del usuario, 66/66):
   * - Grupo: `nropartida` (el reporte muestra una fila por número de partida,
   *   aunque nropartida se repita entre períodos distintos — decisión de negocio).
   * - Fecha: `MIN(fecharegistro)` = fecha de la primera partida del grupo
   *   (MAX daba fechas incorrectas en 10 de 66 filas).
   * - Montos: SUM(débito)/SUM(crédito) de las líneas de la cuenta en todas
   *   las partidas que comparten ese nropartida.
    * - Alcance: doble bandera `sn_anulada='N'` + `sn_contabilizada='S'`
    *   (regla del usuario 29/09/2026): solo movimientos VIGENTES y
    *   CONTABILIZADOS. `sn_anulada='S'` son copias obsoletas de la
    *   reconstrucción y duplicaban 43 documentos (ej: FAC-19 aparecía en
    *   nro 11 y nro 39). Ambas banderas se usan juntas en TODOS los
    *   cálculos de saldos (detalle y catálogo) para que cuadren.
    *
    * Nota: se suma directamente sobre copdadet — evita el self-join que
    * multiplicaba los montos por la cantidad de líneas de cada partida.
    */
  async findSaldosCtaDetalle(ctacontable: string, anio: number | undefined, empresaId: number) {
    if (!ctacontable) {
      throw new BadRequestException('El parámetro ctacontable es requerido');
    }

    const qb = this.copdadetRepo.createQueryBuilder('a')
      .select('a.nropartida', 'nropartida')
      .addSelect('MIN(a.fecharegistro)', 'fecharegistro')
      .addSelect('SUM(a.debito)', 'debito')
      .addSelect('SUM(a.credito)', 'credito')
      .where('a.ctacontable = :ctacontable', { ctacontable })
      .andWhere('a.empresaId = :empresaId', { empresaId })
      .andWhere("a.sn_anulada = 'N'")
      .andWhere("a.sn_contabilizada = 'S'");

    // El detalle corresponde al año del renglón de saldos seleccionado
    // (saldoanterior + movimientos del año)
    if (anio) {
      qb.andWhere('YEAR(a.fecharegistro) = :anio', { anio });
    }

    const movimientos = await qb
      .groupBy('a.nropartida')
      .orderBy('a.nropartida', 'DESC')
      .getRawMany();

    const cta = await this.ctacontablesRepo.findOne({ where: { ctacontable, empresaId } });

    let totalDebito = 0;
    let totalCredito = 0;
    for (const m of movimientos) {
      totalDebito += Number(m.debito) || 0;
      totalCredito += Number(m.credito) || 0;
    }

    return {
      descripcion: cta?.descripcion ?? '',
      movimientos,
      totales: { debito: totalDebito, credito: totalCredito },
    };
  }

  async createSaldoscta(dto: any, currentUser: string) {
    return this.createEntity(this.saldosctaRepo, dto, currentUser);
  }

  async updateSaldoscta(cosaldosctaId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.saldosctaRepo, 'cosaldosctaId', cosaldosctaId, empresaId, dto, currentUser, 'Saldo Cuenta');
  }

  /**
   * Recalcula coctasaldos desde copdadet (versión backend del
   * sp_calcular_saldos_cuenta, correcciones 29/09/2026).
   *
   * Regla de cálculo (definida por el usuario, 29/09/2026):
   * doble bandera `sn_anulada='N'` + `sn_contabilizada='S'` = solo
   * movimientos VIGENTES y CONTABILIZADOS. Ambas banderas se usan juntas
   * en TODOS los cálculos de saldos (catálogo y detalle) para que cuadren.
   *
   * Diferencias vs el SP original:
   * 1. SIN ABS(): guarda el neto firmado SUM(debito-credito). La UI marca
   *    negativo=(C)/positivo=(D) y la suma de los 12 meses debe igualar el
   *    neto del año del detalle; ABS rompe ese cuadre.
   * 2. Filtra por columna `periodo` contable, NO por rango de fecharegistro:
   *    todas las partidas de 2026 se registraron en septiembre (reconstrucción)
   *    y el rango de fechas metía los 12 meses dentro de septiembre.
   * 3. Doble bandera `sn_anulada='N'` + `sn_contabilizada='S'` (mismo criterio
   *    que findSaldosCtaDetalle).
   * 4. empresaId en TODAS las operaciones (SELECT/UPDATE/INSERT): el SP lo
   *    omitía en UPDATE/EXISTS y podía tocar filas de otra empresa.
   *
   * Reglas: solo toca columnas de meses (jamás saldoanterior); crea la fila
   * si la cuenta tiene movimiento y no existe; idempotente.
   * Si `periodo` se omite recalcula los 12 meses.
   */
  async calcularSaldosCta(dto: CalcularSaldosCtaDto, currentUser: string) {
    const { anio, periodo, empresaId } = dto;

    if (!empresaId) throw new BadRequestException('empresaId es requerido');
    if (!anio || anio < 1900 || anio > 2200) {
      throw new BadRequestException(`Año inválido: ${anio}`);
    }
    if (periodo != null && (periodo < 1 || periodo > 12)) {
      throw new BadRequestException(`Período inválido: ${periodo} (debe estar entre 1 y 12)`);
    }

    const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    const periodos = periodo != null ? [periodo] : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

    // Netos firmados por cuenta+período — doble bandera vigente + contabilizada
    const netos = await this.copdadetRepo
      .createQueryBuilder('d')
      .select('d.ctacontable', 'ctacontable')
      .addSelect('d.periodo', 'periodo')
      .addSelect('SUM(d.debito) - SUM(d.credito)', 'neto')
      .where('d.empresaId = :empresaId', { empresaId })
      .andWhere('d.anio = :anio', { anio })
      .andWhere("d.sn_anulada = 'N'")
      .andWhere("d.sn_contabilizada = 'S'")
      .andWhere('d.periodo IS NOT NULL')
      .groupBy('d.ctacontable')
      .addGroupBy('d.periodo')
      .getRawMany();

    const esperado = new Map<string, number>();
    const cuentasConMov = new Set<string>();
    for (const n of netos) {
      const p = Number(n.periodo);
      if (p < 1 || p > 12) continue;
      esperado.set(`${n.ctacontable}|${p}`, Number(n.neto) || 0);
      cuentasConMov.add(n.ctacontable);
    }

    const filas = await this.saldosctaRepo.find({ where: { empresaId, anio } });
    const porCta = new Map(filas.map((f) => [f.ctacontable, f]));

    const fecha = await this.fechaSistema.getFecha(empresaId);
    let filasActualizadas = 0;
    let filasCreadas = 0;
    let celdasCorregidas = 0;

    // Cuentas candidatas: las existentes en coctasaldos + las que tienen movimiento
    const candidatas = new Set<string>([...porCta.keys(), ...cuentasConMov]);

    for (const cta of candidatas) {
      const fila = porCta.get(cta);
      const cambios: Record<string, number> = {};
      let difiere = false;

      for (const p of periodos) {
        const nuevo = esperado.get(`${cta}|${p}`) || 0;
        const guardado = fila ? Number((fila as any)[MESES[p - 1]]) || 0 : 0;
        if (Math.abs(guardado - nuevo) > 0.005) {
          cambios[MESES[p - 1]] = nuevo;
          difiere = true;
          celdasCorregidas++;
        }
      }

      if (!fila) {
        // Solo crear si la cuenta realmente tiene movimiento (evita filas huérfanas)
        if (!cuentasConMov.has(cta)) continue;
        const nueva: Record<string, any> = {
          anio,
          ctacontable: cta,
          saldoanterior: 0,
          empresaId,
          usuarioCreated: currentUser,
        };
        for (let p = 1; p <= 12; p++) {
          nueva[MESES[p - 1]] = periodos.includes(p) ? esperado.get(`${cta}|${p}`) || 0 : 0;
        }
        await this.saldosctaRepo.save(this.saldosctaRepo.create(nueva));
        filasCreadas++;
        continue;
      }

      if (difiere) {
        // QueryBuilder.update: evita el problema de decimales string→number
        await this.saldosctaRepo
          .createQueryBuilder()
          .update()
          .set({ ...cambios, usuarioUpdated: currentUser, fechaUpdated: fecha } as any)
          .where('cosaldosctaId = :id', { id: fila.cosaldosctaId })
          .andWhere('empresaId = :empresaId', { empresaId })
          .execute();
        filasActualizadas++;
      }
    }

    return {
      anio,
      periodo: periodo ?? null,
      empresaId,
      filasEvaluadas: candidatas.size,
      filasActualizadas,
      filasCreadas,
      celdasCorregidas,
    };
  }

  async findAllCierrectable(empresaId: number) {
    return this.findAllByEmpresa(this.cierrectableRepo, empresaId);
  }

  async findCierrectable(cierrectableId: number, empresaId: number) {
    return this.findOneById(this.cierrectableRepo, 'cierrectableId', cierrectableId, empresaId, 'Cierre Contable');
  }

  /** Los registros de cierre (cocierremae) son protegidos: solo se generan desde Cierre Contable */
  async createCierrectable(dto: any, currentUser: string) {
    throw new ForbiddenException(
      'Los registros de cierre contable (cocierremae) son de solo lectura: se generan desde Cierre Contable y no pueden crearse manualmente.',
    );
  }

  async updateCierrectable(cierrectableId: number, empresaId: number, dto: any, currentUser: string) {
    throw new ForbiddenException(
      'Los registros de cierre contable (cocierremae) son de solo lectura: no pueden modificarse bajo ninguna circunstancia.',
    );
  }

  async removeCierrectable(cierrectableId: number, empresaId: number) {
    throw new ForbiddenException(
      'Los registros de cierre contable (cocierremae) son de solo lectura: no pueden eliminarse bajo ninguna circunstancia.',
    );
  }

  // ========== Detalle de Cierre Contable (cocierredet) ==========

  async findAllCierredet(empresaId: number, cocierremaeId?: number) {
    const where: any = { empresaId };
    if (cocierremaeId != null) where.cocierremaeId = cocierremaeId;
    return this.cierredetRepo.find({ where });
  }

  async findCierredet(cocierredetId: number, empresaId: number) {
    return this.findOneById(this.cierredetRepo, 'cocierredetId', cocierredetId, empresaId, 'Detalle de Cierre');
  }

  /** Los detalles de cierre (cocierredet) son protegidos: solo se generan desde Cierre Contable */
  async createCierredet(dto: any, currentUser: string) {
    throw new ForbiddenException(
      'Los detalles de cierre contable (cocierredet) son de solo lectura: se generan desde Cierre Contable y no pueden crearse manualmente.',
    );
  }

  async updateCierredet(cocierredetId: number, empresaId: number, dto: any, currentUser: string) {
    throw new ForbiddenException(
      'Los detalles de cierre contable (cocierredet) son de solo lectura: no pueden modificarse bajo ninguna circunstancia.',
    );
  }

  /**
   * Eliminación física: la tabla cocierredet no tiene columna sn_activo.
   * PROTEGIDO: no se permite eliminar detalles de cierre.
   */
  async removeCierredet(cocierredetId: number, empresaId: number) {
    throw new ForbiddenException(
      'Los detalles de cierre contable (cocierredet) son de solo lectura: no pueden eliminarse bajo ninguna circunstancia.',
    );
  }

  async findAllRepliquidez(empresaId: number) {
    return this.repliquidezRepo.find({
      where: { empresaId } as unknown as FindOptionsWhere<Tcorepliquidez>,
      order: { tcorepliquidezId: 'ASC' } as any,
    });
  }

  async findRepliquidez(tcorepliquidezId: number) {
    return this.findOneByIdNoEmpresa(this.repliquidezRepo, 'tcorepliquidezId', tcorepliquidezId, 'Reporte Liquidez');
  }

  async createRepliquidez(dto: any, currentUser: string) {
    return this.createEntity(this.repliquidezRepo, dto, currentUser);
  }

  async updateRepliquidez(tcorepliquidezId: number, dto: any, currentUser: string) {
    return this.updateEntityNoEmpresa(this.repliquidezRepo, 'tcorepliquidezId', tcorepliquidezId, dto, currentUser, 'Reporte Liquidez');
  }

  async removeRepliquidez(tcorepliquidezId: number) {
    return this.softDeleteNoEmpresa(this.repliquidezRepo, 'tcorepliquidezId', tcorepliquidezId, 'Reporte Liquidez');
  }

  async findAllFactordecambio(empresaId: number) {
    return this.factordecambioRepo.find({
      where: { empresaId } as unknown as FindOptionsWhere<Ttipofactordecambios>,
      order: { fecharegistro: 'DESC' } as any,
    });
  }

  async findFactordecambio(factordecambioId: number) {
    return this.findOneByIdNoEmpresa(this.factordecambioRepo, 'factordecambioId', factordecambioId, 'Factor de Cambio');
  }

  /** REGLA: el precio de venta nunca puede ser menor al precio de compra */
  private validarPreciosFactordecambio(preciocompra: any, precioventa: any) {
    const compra = Number(preciocompra ?? 0);
    const venta = Number(precioventa ?? 0);
    if (venta < compra) {
      throw new BadRequestException('El Precio Venta no puede ser menor al Precio Compra');
    }
  }

  async createFactordecambio(dto: any, currentUser: string) {
    const payload = { ...dto };
    this.validarPreciosFactordecambio(payload.preciocompra, payload.precioventa);
    // La columna factordecambioId NO es AUTO_INCREMENT en la tabla y el formulario
    // la oculta → si no viene el ID (o llega en 0), se asigna el consecutivo de la tabla
    if (!payload.factordecambioId) {
      const r = await this.factordecambioRepo
        .createQueryBuilder('f')
        .select('MAX(f.factordecambioId)', 'max')
        .getRawOne();
      payload.factordecambioId = (Number(r?.max) || 0) + 1;
    }
    // Fecha de registro por defecto = tempresas.fechasistema (no el reloj del servidor)
    if (!payload.fecharegistro) {
      payload.fecharegistro = await this.fechaSistema.getFecha(payload.empresaId);
    }
    return this.createEntity(this.factordecambioRepo, payload, currentUser);
  }

  async updateFactordecambio(factordecambioId: number, dto: any, currentUser: string) {
    // Validar contra los valores finales (los que llegan + los guardados)
    const actual = await this.findFactordecambio(factordecambioId);
    this.validarPreciosFactordecambio(
      dto?.preciocompra ?? actual.preciocompra,
      dto?.precioventa ?? actual.precioventa,
    );
    return this.updateEntityNoEmpresa(this.factordecambioRepo, 'factordecambioId', factordecambioId, dto, currentUser, 'Factor de Cambio');
  }

  async findAllPlantillabalancesmae(empresaId: number) {
    return this.findAllByEmpresa(this.plantillabalancesmaeRepo, empresaId);
  }

  async findPlantillabalancesmae(cocdefbalmaId: number, empresaId: number) {
    return this.findOneById(this.plantillabalancesmaeRepo, 'cocdefbalmaId', cocdefbalmaId, empresaId, 'Plantilla Balance Mae');
  }

  async createPlantillabalancesmae(dto: any, currentUser: string) {
    try {
      return await this.createEntity(this.plantillabalancesmaeRepo, dto, currentUser);
    } catch (error) {
      throw this.traducirErrorIntegridadPlantilla(
        error,
        `Ya existe una plantilla de balances con la descripción "${dto.descripcion}"`,
        'El registro relacionado no existe',
      );
    }
  }

  async updatePlantillabalancesmae(cocdefbalmaId: number, empresaId: number, dto: any, currentUser: string) {
    try {
      return await this.updateEntity(this.plantillabalancesmaeRepo, 'cocdefbalmaId', cocdefbalmaId, empresaId, dto, currentUser, 'Plantilla Balance Mae');
    } catch (error) {
      throw this.traducirErrorIntegridadPlantilla(
        error,
        `Ya existe una plantilla de balances con la descripción "${dto.descripcion}"`,
        'El registro relacionado no existe',
      );
    }
  }

  async removePlantillabalancesmae(cocdefbalmaId: number, empresaId: number) {
    return this.softDelete(this.plantillabalancesmaeRepo, 'cocdefbalmaId', cocdefbalmaId, empresaId, 'Plantilla Balance Mae');
  }

  async findAllPlantillabalancesdet(empresaId: number, cocdefbalmaId?: number) {
    if (cocdefbalmaId) {
      return this.plantillabalancesdetRepo.find({
        where: { empresaId, cocdefbalmaId, sn_activo: 'S' } as any,
        order: { renglon: 'ASC', columna: 'ASC' },
      });
    }
    return this.plantillabalancesdetRepo.find({
      where: { empresaId, sn_activo: 'S' } as any,
    });
  }

  async findPlantillabalancesdet(tcoplantillabalancesdetid: number, empresaId: number) {
    return this.findOneById(this.plantillabalancesdetRepo, 'tcoplantillabalancesdetid', tcoplantillabalancesdetid, empresaId, 'Plantilla Balance Det');
  }

  /**
   * Crea una línea de plantilla de balances.
   * Reglas: columna obligatoria (1..4), cuenta contable obligatoria y
   * no repetida dentro de la misma plantilla.
   */
  async createPlantillabalancesdet(dto: any, currentUser: string) {
    const ctacontable = typeof dto.ctacontable === 'string' ? dto.ctacontable.trim() : dto.ctacontable;
    dto.ctacontable = ctacontable;
    if (!dto.cocdefbalmaId) {
      throw new BadRequestException('La plantilla de balance es obligatoria');
    }
    if (!ctacontable) {
      throw new BadRequestException('La cuenta contable es obligatoria');
    }
    this.validarColumnaPlantillaBalances(dto.columna);
    await this.validarCtaDuplicadaPlantillaBalances(dto.cocdefbalmaId, ctacontable, dto.empresaId);
    try {
      return await this.createEntity(this.plantillabalancesdetRepo, dto, currentUser);
    } catch (error) {
      throw this.traducirErrorIntegridadPlantilla(
        error,
        `La cuenta contable ${ctacontable} ya está registrada en esta plantilla`,
        `La cuenta contable ${ctacontable} no existe en el plan de cuentas`,
      );
    }
  }

  /**
   * Actualiza una línea de plantilla de balances (payload parcial permitido).
   * Valida columna (si viene) y cuenta duplicada (si cambia la cuenta o la plantilla).
   */
  async updatePlantillabalancesdet(tcoplantillabalancesdetid: number, empresaId: number, dto: any, currentUser: string) {
    if ('columna' in dto) {
      this.validarColumnaPlantillaBalances(dto.columna);
    }
    const cambiaCuenta = 'ctacontable' in dto || 'cocdefbalmaId' in dto;
    if ('ctacontable' in dto) {
      dto.ctacontable = typeof dto.ctacontable === 'string' ? dto.ctacontable.trim() : dto.ctacontable;
      if (!dto.ctacontable) {
        throw new BadRequestException('La cuenta contable es obligatoria');
      }
    }
    if (cambiaCuenta) {
      const actual = await this.findOneById(
        this.plantillabalancesdetRepo, 'tcoplantillabalancesdetid', tcoplantillabalancesdetid, empresaId, 'Plantilla Balance Det',
      );
      const ctacontable = dto.ctacontable ?? actual.ctacontable;
      const cocdefbalmaId = dto.cocdefbalmaId ?? actual.cocdefbalmaId;
      await this.validarCtaDuplicadaPlantillaBalances(cocdefbalmaId, ctacontable, empresaId, tcoplantillabalancesdetid);
    }
    try {
      return await this.updateEntity(this.plantillabalancesdetRepo, 'tcoplantillabalancesdetid', tcoplantillabalancesdetid, empresaId, dto, currentUser, 'Plantilla Balance Det');
    } catch (error) {
      const cta = typeof dto.ctacontable === 'string' ? dto.ctacontable : '';
      throw this.traducirErrorIntegridadPlantilla(
        error,
        `La cuenta contable ${cta} ya está registrada en esta plantilla`.trim(),
        `La cuenta contable ${cta} no existe en el plan de cuentas`.trim(),
      );
    }
  }

  /**
   * Valida la columna de una línea de plantilla de balances:
   * es obligatoria y su rango de elección es 1 a 4.
   */
  private validarColumnaPlantillaBalances(columna: any): void {
    if (columna === null || columna === undefined || columna === '') {
      throw new BadRequestException('La columna es obligatoria');
    }
    const n = Number(columna);
    if (!Number.isInteger(n) || n < 1 || n > 4) {
      throw new BadRequestException('La columna debe estar entre 1 y 4');
    }
  }

  /**
   * Impide el registro duplicado de la cuenta contable dentro de la misma
   * plantilla (se ignora el tipo D/C: la cuenta no puede repetirse).
   */
  private async validarCtaDuplicadaPlantillaBalances(
    cocdefbalmaId: number,
    ctacontable: string,
    empresaId?: number,
    excluirId?: number,
  ): Promise<void> {
    const base: any = { cocdefbalmaId, ctacontable, sn_activo: 'S' };
    if (empresaId) {
      base.empresaId = empresaId;
    }
    const existe = await this.plantillabalancesdetRepo.findOne({
      where: excluirId ? { ...base, tcoplantillabalancesdetid: Not(excluirId) } : base,
    } as any);
    if (existe) {
      throw new BadRequestException(`La cuenta contable ${ctacontable} ya está registrada en esta plantilla`);
    }
  }

  /**
   * Traduce violaciones de integridad (clave única / foráneas) a HTTP 400
   * con mensaje legible; cualquier otro error se relanza tal cual.
   */
  private traducirErrorIntegridadPlantilla(error: any, mensajeDuplicado: string, mensajeFk?: string): any {
    const code = error?.driverError?.code ?? error?.code;
    if (code === 'ER_DUP_ENTRY') {
      return new BadRequestException(mensajeDuplicado);
    }
    if (code === 'ER_NO_REFERENCED_ROW_2' || code === 'ER_NO_REFERENCED_ROW_1') {
      return new BadRequestException(mensajeFk ?? 'El registro relacionado no existe');
    }
    return error;
  }

  async removePlantillabalancesdet(tcoplantillabalancesdetid: number, empresaId: number) {
    return this.softDelete(this.plantillabalancesdetRepo, 'tcoplantillabalancesdetid', tcoplantillabalancesdetid, empresaId, 'Plantilla Balance Det');
  }

  // ===== Reporte de Balances Dinámico =====

  /**
   * Genera el reporte de balances dinámico/parametrizado.
   *
   * Reglas de negocio:
   * 1. Orden de presentación: por `renglon`.
   * 2. `columna` = ubicación dentro de una tabla de máx. 7 columnas (1..7).
   *    El valor de la línea se muestra SOLO en esa columna.
   * 3. Columna 0 (solo balances, cuentas diferentes de Ingresos/Gastos):
   *    = Saldo Acumulado antes del período en curso.
   * 4. Fórmula para balances / reportes que NO son de resultado:
   *    Saldo Acumulado + (Débitos - Créditos) del período → se muestra en la
   *    columna indicada por el usuario (`columna` de la plantilla).
   * 5. Fuentes: coctamov (movimientos del período) + cocierredet (acumulado anterior).
   * 6. Mayorización: cada línea suma su cuenta + descendientes (prefijo + jerarquía padre).
   * 7. Estado de Resultado: la Columna 1 (Parcial) se totaliza como
   *    (ingresos) − (gastos): cuentas de naturaleza C suman y las de
   *    naturaleza D restan (devoluciones/rebajas/descuentos y gastos tipo 5).
   */
  async generarBalanceDinamico(dto: ReporteBalanceDinamicoDto) {
    const { empresaId, plantillaId, nivelDetalle, periodo, anio } = dto;

    // ── 1. Plantilla cabecera ──
    const mae = await this.plantillabalancesmaeRepo.findOne({
      where: { cocdefbalmaId: plantillaId, empresaId } as any,
    });
    if (!mae) throw new NotFoundException(`Plantilla de balance ${plantillaId} no encontrada`);

    // ── 2. Plantilla detalle (líneas activas) ordenadas por renglon ──
    const det = await this.plantillabalancesdetRepo.find({
      where: { cocdefbalmaId: plantillaId, empresaId, sn_activo: 'S' } as any,
      order: { renglon: 'ASC', columna: 'ASC' } as any,
    });

    // ── 3. Nombre de empresa ──
    const empresa = await this.empresasRepo.findOne({ where: { empresaId } as any });
    const empresaName = empresa?.descripcion ?? '';

    // ── 4. Catálogo de cuentas ──
    const cuentas = await this.ctacontablesRepo.find({
      where: { empresaId, sn_activo: 'S' } as any,
    });
    const ctaMap = new Map(cuentas.map((c) => [c.ctacontable, c]));

    // ── 5. Acumulado ANTERIOR al período (cocierredet) → Columna 0 ──
    const acumMap = new Map<string, number>();
    if (periodo != null && anio != null) {
      const periodoAnt = periodo === 1 ? 12 : periodo - 1;
      const anioAnt = periodo === 1 ? anio - 1 : anio;
      const cierres = await this.cierredetRepo.find({
        where: { empresaId, anio: anioAnt, periodo: periodoAnt } as any,
      });
      for (const sc of cierres) {
        acumMap.set(sc.ctacontable, (acumMap.get(sc.ctacontable) || 0) + (Number(sc.saldo) || 0));
      }
    } else {
      // Sin período: acumulado = cierre más reciente por cuenta
      const cierres = await this.cierredetRepo.find({ where: { empresaId } as any });
      for (const sc of cierres) {
        const key = `${sc.ctacontable}`;
        const actual = acumMap.get(key) || 0;
        // Simple suma (podría mejorarse tomando solo el último período)
        acumMap.set(key, actual + (Number(sc.saldo) || 0));
      }
    }

    // ── 6. Movimientos del PERÍODO (coctamov): Débitos - Créditos ──
    const movMap = new Map<string, { debe: number; haber: number }>();
    if (periodo != null && anio != null) {
      const movimientos = await this.movctaRepo.find({
        where: { empresaId, anio, periodo } as any,
      });
      for (const mov of movimientos) {
        const ex = movMap.get(mov.ctacontable) || { debe: 0, haber: 0 };
        ex.debe += Number(mov.debe) || 0;
        ex.haber += Number(mov.haber) || 0;
        movMap.set(mov.ctacontable, ex);
      }
    } else {
      const movimientos = await this.movctaRepo.find({ where: { empresaId } as any });
      for (const mov of movimientos) {
        const ex = movMap.get(mov.ctacontable) || { debe: 0, haber: 0 };
        ex.debe += Number(mov.debe) || 0;
        ex.haber += Number(mov.haber) || 0;
        movMap.set(mov.ctacontable, ex);
      }
    }

    // ── 7. Mapa de hijos por padre (jerarquía explícita) ──
    const hijosPorPadre = new Map<string, string[]>();
    for (const cta of cuentas) {
      if (cta.padre) {
        const arr = hijosPorPadre.get(cta.padre) || [];
        arr.push(cta.ctacontable);
        hijosPorPadre.set(cta.padre, arr);
      }
    }

    // ── 8. Mayorización recursiva (acum + movimientos por separado) ──
    interface Mayorizado { acum: number; debe: number; haber: number }
    const mayorizadoMap = new Map<string, Mayorizado>();
    const visitados = new Set<string>();

    const calcularMayorizado = (codigo: string): Mayorizado => {
      const cache = mayorizadoMap.get(codigo);
      if (cache) return cache;
      if (visitados.has(codigo)) return { acum: 0, debe: 0, haber: 0 };
      visitados.add(codigo);

      const mov = movMap.get(codigo);
      let acum = acumMap.get(codigo) || 0;
      let debe = mov?.debe || 0;
      let haber = mov?.haber || 0;

      // Hijos por prefijo de código (ej: "4110" → "4110-001", "4110-002")
      for (const [ctaCod, m] of movMap) {
        if (ctaCod !== codigo && ctaCod.startsWith(codigo)) {
          debe += m.debe;
          haber += m.haber;
        }
      }
      for (const [ctaCod, a] of acumMap) {
        if (ctaCod !== codigo && ctaCod.startsWith(codigo)) {
          acum += a;
        }
      }

      // Hijos por campo padre (jerarquía explícita, si no cubiertos por prefijo)
      const hijos = hijosPorPadre.get(codigo) || [];
      for (const hijo of hijos) {
        if (!hijo.startsWith(codigo)) {
          const h = calcularMayorizado(hijo);
          acum += h.acum;
          debe += h.debe;
          haber += h.haber;
        }
      }

      const resultado: Mayorizado = { acum, debe, haber };
      mayorizadoMap.set(codigo, resultado);
      return resultado;
    };

    for (const cta of cuentas) {
      calcularMayorizado(cta.ctacontable);
    }

    // ── 9. Determinar si es balance (cuentas 1/2/3) vs resultado (4/5/6/7) ──
    // "Solo cuando las cuentas sean diferentes de Ingresos y Gastos se muestra Col 0"
    const esBalance = det.some((d) => d.ctacontable && /^[123]/.test(d.ctacontable));

    // ── 10. Construir líneas del reporte (orden por renglon) ──
    const lineasBrutas = det
      .filter((d) => {
        if (nivelDetalle != null && d.ctacontable) {
          const cta = ctaMap.get(d.ctacontable);
          if (cta && cta.nivel != null) return cta.nivel <= nivelDetalle;
        }
        return true;
      })
      .map((d) => {
        const cta = d.ctacontable ? ctaMap.get(d.ctacontable) : undefined;
        const nivel = cta?.nivel ?? null;
        const col = d.columna ?? 0;

        let acum = 0;
        let debe = 0;
        let haber = 0;
        if (d.ctacontable) {
          const m = mayorizadoMap.get(d.ctacontable) ?? calcularMayorizado(d.ctacontable);
          acum = m.acum;
          debe = m.debe;
          haber = m.haber;
        }

        // Fórmula: Saldo Acumulado + (Débitos - Créditos) del período
        // En contabilidad NO existen saldos negativos: se presenta en valor absoluto
        const valor = Math.abs(acum + (debe - haber));

        // Columna 0 = Saldo acumulado ANTES del período (solo balances), valor absoluto
        const col0 = esBalance ? Math.abs(acum) : null;

        return {
          empresaName,
          balancename: mae.descripcion,
          ctacontable: d.ctacontable ?? '',
          descripcion: d.descripcion ?? '',
          columna: col,
          renglon: d.renglon ?? 0,
          tipo: d.tipo ?? '',
          nivel,
          acum,
          debe,
          haber,
          valor,
          col0,
        };
      })
      .sort((a, b) => a.renglon - b.renglon || a.columna - b.columna);

    // ── 11. Columnas usadas (1..7) ──
    const columnasSet = new Set<number>();
    for (const l of lineasBrutas) {
      if (l.columna >= 1 && l.columna <= 7) columnasSet.add(l.columna);
    }
    const columnasUsadas = Array.from(columnasSet).sort((a, b) => a - b);

    // ── 12. Totales por columna ──
    const totales: Record<string, number> = {};
    if (esBalance) {
      totales['0'] = lineasBrutas.reduce((s, l) => s + (l.col0 ?? 0), 0);
    }
    for (const col of columnasUsadas) {
      // REGLA DE NEGOCIO — Estado de Resultado, columnas 1 a 4 (Parcial y Totales):
      //   Total = (todos los ingresos) − (todos los gastos)
      //   Ingresos  = ventas (cuentas de naturaleza C)
      //   Menos     = rebajas, devoluciones y descuentos sobre ventas (naturaleza D dentro de tipo 4)
      //   Menos     = todos los gastos (cuentas de tipo 5, naturaleza D)
      //   Se aplica el signo según la naturaleza de la cuenta: C suma, D resta.
      //   Aplica a cualquier columna 1..4 por si el usuario reordena la presentación
      //   de las columnas de totales en las cuentas registradas (col 5..7 no aplica).
      if (!esBalance && col >= 1 && col <= 4) {
        totales[String(col)] = lineasBrutas
          .filter((l) => l.columna === col && l.ctacontable)
          .reduce((s, l) => {
            const naturaleza = ctaMap.get(l.ctacontable)?.naturaleza || 'D';
            return s + (naturaleza === 'C' ? l.valor : -l.valor);
          }, 0);
        continue;
      }
      const total = lineasBrutas
        .filter((l) => l.columna === col)
        .reduce((s, l) => s + l.valor, 0);
      totales[String(col)] = total;
    }

    return {
      empresaName,
      balancename: mae.descripcion,
      plantillaId,
      nivelDetalle: nivelDetalle ?? null,
      periodo: periodo ?? null,
      anio: anio ?? null,
      esBalance,
      mostrarCol0: esBalance,
      columnasUsadas,
      lineas: lineasBrutas,
      totales,
    };
  }

  async findAllRepdiarios(empresaId: number) {
    return this.repdiariosRepo.find({
      where: { empresaId } as unknown as FindOptionsWhere<Tcorepdiarios>,
    });
  }

  async findRepdiarios(tcorepdiariosId: number) {
    return this.findOneByIdNoEmpresa(this.repdiariosRepo, 'tcorepdiariosId', tcorepdiariosId, 'Reporte Diario');
  }

  async createRepdiarios(dto: any, currentUser: string) {
    return this.createEntity(this.repdiariosRepo, dto, currentUser);
  }

  async updateRepdiarios(tcorepdiariosId: number, dto: any, currentUser: string) {
    return this.updateEntityNoEmpresa(this.repdiariosRepo, 'tcorepdiariosId', tcorepdiariosId, dto, currentUser, 'Reporte Diario');
  }

  async removeRepdiarios(tcorepdiariosId: number) {
    return this.softDeleteNoEmpresa(this.repdiariosRepo, 'tcorepdiariosId', tcorepdiariosId, 'Reporte Diario');
  }

  async findAllRepbalances(empresaId: number) {
    return this.repbalancesRepo.find({
      where: { empresaId } as unknown as FindOptionsWhere<Tcorepbalances>,
      order: { balcomId: 'ASC' } as any,
    });
  }

  async findRepbalances(balcomId: number) {
    return this.findOneByIdNoEmpresa(this.repbalancesRepo, 'balcomId', balcomId, 'Reporte Balance');
  }

  async createRepbalances(dto: any, currentUser: string) {
    return this.createEntity(this.repbalancesRepo, dto, currentUser);
  }

  async updateRepbalances(balcomId: number, dto: any, currentUser: string) {
    return this.updateEntityNoEmpresa(this.repbalancesRepo, 'balcomId', balcomId, dto, currentUser, 'Reporte Balance');
  }

  async findAllPeriodoctable(empresaId: number) {
    return this.findAllByEmpresa(this.periodoctableRepo, empresaId);
  }

  async findPeriodoctable(periodoscontableId: number, empresaId: number) {
    return this.findOneById(this.periodoctableRepo, 'periodoscontableId', periodoscontableId, empresaId, 'Periodo Contable');
  }

  async createPeriodoctable(dto: any, currentUser: string) {
    // REGLA: un período solo puede cerrarse desde Cierre Contable (genera la partida de cierre)
    if (dto?.sn_abierto === 'N') {
      throw new ForbiddenException(
        'No se puede crear un período cerrado. Los cierres se realizan desde Cierre Contable.',
      );
    }
    const motivo = await this.explicarProteccionPeriodo(
      { nroanio: dto?.nroanio, nromes: dto?.nromes },
      dto?.empresaId,
    );
    if (motivo) throw new ForbiddenException(motivo);
    return this.createEntity(this.periodoctableRepo, dto, currentUser);
  }

  async updatePeriodoctable(periodoscontableId: number, empresaId: number, dto: any, currentUser: string) {
    const actual = await this.findPeriodoctable(periodoscontableId, empresaId);
    // REGLA INVARIABLE: período cerrado = inmutable; y un período anterior a otro cerrado también
    const motivo = await this.explicarProteccionPeriodo(actual, empresaId);
    if (motivo) throw new ForbiddenException(motivo);
    // Cerrar un período desde el catálogo saltaría la partida de cierre contable
    if (dto?.sn_abierto === 'N') {
      throw new BadRequestException(
        'No se puede cerrar un período desde el catálogo. Use Cierre Contable para generar la partida de cierre.',
      );
    }
    return this.updateEntity(this.periodoctableRepo, 'periodoscontableId', periodoscontableId, empresaId, dto, currentUser, 'Periodo Contable');
  }

  async removePeriodoctable(periodoscontableId: number, empresaId: number) {
    const actual = await this.findPeriodoctable(periodoscontableId, empresaId);
    const motivo = await this.explicarProteccionPeriodo(actual, empresaId);
    if (motivo) throw new ForbiddenException(motivo);
    // La entidad coperiodoctable no tiene columna sn_activo → el softDelete genérico
    // sería un no-op silencioso, por eso es eliminación física (solo alcanza a períodos abiertos)
    const cierre = await this.cierrectableRepo.findOne({
      where: { anio: actual.nroanio, periodo: actual.nromes, empresaId } as unknown as FindOptionsWhere<Cocierrectable>,
    });
    if (cierre) {
      throw new ForbiddenException(
        `El período ${actual.nromes}/${actual.nroanio} tiene cierre contable registrado: no puede eliminarse.`,
      );
    }
    await this.periodoctableRepo.delete({ periodoscontableId, empresaId });
    return actual;
  }

  /**
   * REGLA DE PROTECCIÓN DE PERÍODOS CONTABLES:
   * 1) Un período cerrado (sn_abierto='N') es inmutable para siempre: no se modifica,
   *    no se reabre y no se elimina bajo ninguna circunstancia.
   * 2) Si existe un período cerrado posterior, los anteriores (previos/antecesores)
   *    tampoco son modificables.
   * Devuelve el motivo de protección, o null si el período no está protegido.
   */
  private async explicarProteccionPeriodo(
    periodo: { nroanio?: number; nromes?: number; sn_abierto?: string },
    empresaId: number,
  ): Promise<string | null> {
    if (!periodo || periodo.nroanio == null || periodo.nromes == null) return null;

    if (periodo.sn_abierto === 'N') {
      return `El período ${periodo.nromes}/${periodo.nroanio} está cerrado: no es modificable ni puede reabrirse bajo ninguna circunstancia`;
    }

    const cerrados = await this.periodoctableRepo.find({
      where: { empresaId, sn_abierto: 'N' } as unknown as FindOptionsWhere<Coperiodoctable>,
    });
    const hayCerradoPosterior = cerrados.some(
      (c) => c.nroanio > periodo.nroanio! || (c.nroanio === periodo.nroanio && c.nromes > periodo.nromes!),
    );
    if (hayCerradoPosterior) {
      return `Existe un período cerrado posterior al ${periodo.nromes}/${periodo.nroanio}: los períodos previos o antecesores no son modificables`;
    }
    return null;
  }

  async findAllCopdamae(empresaId: number) {
    return this.copdamaeRepo.find({
      where: { empresaId } as unknown as FindOptionsWhere<Copdamae>,
      order: { fecharegistro: 'DESC' } as any,
    });
  }

  async findCopdamae(partidaId: number, empresaId: number) {
    return this.findOneById(this.copdamaeRepo, 'partidaId', partidaId, empresaId, 'Partida Mayor');
  }

  /**
   * Control de partidas cerradas (sn_cerrada) — "mejorar el control de lo cerrado".
   *
   * Bloquea la operación si:
   * 1. La partida está marcada sn_cerrada='S' (se marca al cerrar su período
   *    contable en realizarCierre), o
   * 2. Fallback: su período contable está cerrado en coperiodoctable
   *    (cubre partidas creadas manualmente en períodos ya cerrados).
   *
   * Llamar SIEMPRE antes de crear/modificar/eliminar cabecera o líneas.
   */
  private async exigirPartidaModificable(
    ref: {
      empresaId: number;
      anio?: number | null;
      periodo?: number | null;
      sn_cerrada?: string;
    },
    etiqueta: string,
    accion: string,
  ): Promise<void> {
    if (ref.sn_cerrada === 'S') {
      throw new ForbiddenException(`${etiqueta} está cerrada: ${accion}`);
    }
    if (ref.anio && ref.periodo) {
      const per = await this.periodoctableRepo.findOne({
        where: {
          nroanio: ref.anio,
          nromes: ref.periodo,
          empresaId: ref.empresaId,
        } as unknown as FindOptionsWhere<Coperiodoctable>,
      });
      if (per && per.sn_abierto !== 'S') {
        throw new ForbiddenException(
          `${etiqueta} pertenece al período ${ref.periodo}/${ref.anio} (cerrado): ${accion}`,
        );
      }
    }
  }

  async createCopdamae(dto: CreateCopdamaeDto, currentUser: string) {
    await this.exigirPartidaModificable(
      { empresaId: dto.empresaId, anio: dto.anio, periodo: dto.periodo, sn_cerrada: dto.sn_cerrada },
      'La partida',
      'no puede registrarse en un período cerrado',
    );
    return this.createEntity(this.copdamaeRepo, dto, currentUser);
  }

  async updateCopdamae(partidaId: number, empresaId: number, dto: UpdateCopdamaeDto, currentUser: string) {
    const actual = await this.findOneById(this.copdamaeRepo, 'partidaId', partidaId, empresaId, 'Partida Mayor');
    await this.exigirPartidaModificable(
      actual,
      `La partida #${actual.nropartida}`,
      'no puede modificarse ni eliminarse',
    );
    return this.updateEntity(this.copdamaeRepo, 'partidaId', partidaId, empresaId, dto, currentUser, 'Partida Mayor');
  }

  async removeCopdamae(partidaId: number, empresaId: number) {
    const actual = await this.findOneById(this.copdamaeRepo, 'partidaId', partidaId, empresaId, 'Partida Mayor');
    await this.exigirPartidaModificable(
      actual,
      `La partida #${actual.nropartida}`,
      'no puede modificarse ni eliminarse',
    );
    // Invariante (estado actual): partida anulada ⇒ ya no está contabilizada
    const fechaUpdated = await this.fechaSistema.getFecha(empresaId);
    Object.assign(actual, {
      sn_anulada: 'S',
      sn_contabilizada: 'N',
      fechaUpdated,
    });
    const saved = await this.copdamaeRepo.save(actual);
    // Cascada: las líneas de la partida siguen el estado del maestro
    await this.copdadetRepo.createQueryBuilder()
      .update(Copdadet)
      .set({ sn_anulada: 'S', sn_contabilizada: 'N', fechaUpdated })
      .where('partidaId = :pid', { pid: partidaId })
      .execute();
    return saved;
  }

  async findAllCopdadet(empresaId: number, copdamaeId?: number) {
    if (copdamaeId) {
      return this.copdadetRepo.find({ where: { empresaId, partidaId: copdamaeId }, order: { nrofila: 'ASC' } });
    }
    return this.findAllByEmpresa(this.copdadetRepo, empresaId);
  }

  async findCopdadet(copdadetId: number, empresaId: number) {
    return this.findOneById(this.copdadetRepo, 'copdadetId', copdadetId, empresaId, 'Partida Detalle');
  }

  async createCopdadet(dto: CreateCopdadetDto, currentUser: string) {
    // No permitir agregar líneas a una partida cerrada (bandera o período)
    const mae = await this.copdamaeRepo.findOne({
      where: { partidaId: dto.partidaId, empresaId: dto.empresaId } as unknown as FindOptionsWhere<Copdamae>,
    });
    if (mae) {
      await this.exigirPartidaModificable(
        mae,
        `La partida #${mae.nropartida}`,
        'no puede recibir nuevas líneas',
      );
    }
    return this.createEntity(this.copdadetRepo, dto, currentUser);
  }

  async updateCopdadet(copdadetId: number, empresaId: number, dto: UpdateCopdadetDto, currentUser: string) {
    const det = await this.findOneById(this.copdadetRepo, 'copdadetId', copdadetId, empresaId, 'Partida Detalle');
    await this.exigirLineaCopdadetModificable(det, 'no puede modificarse ni eliminarse');
    return this.updateEntity(this.copdadetRepo, 'copdadetId', copdadetId, empresaId, dto, currentUser, 'Partida Detalle');
  }

  async removeCopdadet(copdadetId: number, empresaId: number) {
    const det = await this.findOneById(this.copdadetRepo, 'copdadetId', copdadetId, empresaId, 'Partida Detalle');
    await this.exigirLineaCopdadetModificable(det, 'no puede modificarse ni eliminarse');
    // Invariante (estado actual): línea anulada ⇒ ya no está contabilizada
    Object.assign(det, {
      sn_anulada: 'S',
      sn_contabilizada: 'N',
      fechaUpdated: await this.fechaSistema.getFecha(empresaId),
    });
    return this.copdadetRepo.save(det);
  }

  /**
   * Valida que una línea de partida (copdadet) no pertenezca a una partida cerrada.
   * Usa el maestro como referencia (anio/periodo/sn_cerrada); si el maestro no
   * existe, valida con los propios campos de la línea.
   */
  private async exigirLineaCopdadetModificable(det: Copdadet, accion: string): Promise<void> {
    const mae = await this.copdamaeRepo.findOne({
      where: { partidaId: det.partidaId, empresaId: det.empresaId } as unknown as FindOptionsWhere<Copdamae>,
    });
    const ref = mae ?? det;
    const nro = mae?.nropartida ?? det.nropartida ?? det.partidaId;
    const etiqueta = det.nrofila != null
      ? `La línea ${det.nrofila} de la partida #${nro}`
      : `La partida #${nro}`;
    await this.exigirPartidaModificable(ref, etiqueta, accion);
  }

  /**
   * Lista movimientos contables enriquecidos con saldo acumulado
   * del periodo anterior desde cocierredet y descripcion de la cuenta.
   *
   * REGLA CONTABLE: NUNCA saldos negativos.
   * - Naturaleza D (deudora): saldo = saldoAcum + debe - haber → Math.abs
   * - Naturaleza C (acreedora): saldo = saldoAcum + haber - debit → Math.abs
   * La dirección (D/C) la indica el campo 'naturaleza', no el signo.
   *
   * Filtros opcionales: anio, periodo, descripcion (parcial, de la cuenta).
   */
  async findAllMovcta(
    empresaId: number,
    filtros?: { anio?: number; periodo?: number; descripcion?: string },
  ) {
    // 1. Movimientos de la empresa (filtros de anio/periodo a nivel SQL)
    const where: any = { empresaId };
    if (filtros?.anio != null && !isNaN(filtros.anio)) where.anio = filtros.anio;
    if (filtros?.periodo != null && !isNaN(filtros.periodo)) where.periodo = filtros.periodo;

    const movimientos = await this.movctaRepo.find({
      where: where as unknown as FindOptionsWhere<Coctamov>,
      order: { ctacontable: 'ASC', anio: 'DESC', periodo: 'DESC' } as any,
    });

    if (movimientos.length === 0) return [];

    // 2. Mapa ctacontable → { descripcion, naturaleza } (para filtro, columna y cálculo)
    const cuentas = await this.ctacontablesRepo.find({
      where: { empresaId } as unknown as FindOptionsWhere<Coctacontables>,
    });
    const ctaMap = new Map(cuentas.map(c => [c.ctacontable, { descripcion: c.descripcion || '', naturaleza: c.naturaleza || 'D' }]));

    // 3. Todos los saldos de cierre de la empresa
    const cierres = await this.cierredetRepo.find({
      where: { empresaId } as unknown as FindOptionsWhere<Cocierredet>,
    });

    // 4. Mapa para lookup rápido: "ctacontable-anio-periodo" → saldo
    const cierreMap = new Map<string, number>();
    for (const c of cierres) {
      const key = `${c.ctacontable}-${c.anio}-${c.periodo}`;
      cierreMap.set(key, Number(c.saldo) || 0);
    }

    // 5. Enriquecer cada movimiento con saldo del periodo anterior + descripcion
    // REGLA CONTABLE: NUNCA saldos negativos.
    // - Naturaleza D (deudora): saldo = saldoAcum + debe - haber, se presenta en positivo.
    // - Naturaleza C (acreedora): saldo = saldoAcum + haber - debit, se presenta en positivo.
    // La dirección (D/C) la indica el campo naturaleza, no el signo.
    let resultado = movimientos.map(mov => {
      // Calcular periodo/anio anterior
      const perAnt = mov.periodo === 1 ? 12 : mov.periodo - 1;
      const anioAnt = mov.periodo === 1 ? mov.anio - 1 : mov.anio;

      const key = `${mov.ctacontable}-${anioAnt}-${perAnt}`;
      const saldoAcum = cierreMap.get(key) ?? 0;
      const debe = Number(mov.debe) || 0;
      const haber = Number(mov.haber) || 0;

      const info = ctaMap.get(mov.ctacontable);
      const naturaleza = info?.naturaleza || 'D';

      // Fórmula según naturaleza, resultado SIEMPRE en positivo
      const saldoCalc = naturaleza === 'C'
        ? saldoAcum + (haber - debe)
        : saldoAcum + (debe - haber);
      const saldo = Math.abs(saldoCalc);

      return {
        movctascontablesId: mov.movctascontablesId,
        monedaId: mov.monedaId,
        ctacontable: mov.ctacontable,
        descripcion: info?.descripcion || '',
        naturaleza,
        anio: mov.anio,
        periodo: mov.periodo,
        sacum: Math.abs(saldoAcum),
        debe,
        haber,
        saldo,
        fecultmov: mov.fecultmov,
        ultnropda: mov.ultnropda,
        empresaId: mov.empresaId,
        usuarioCreated: mov.usuarioCreated,
      };
    });

    // 6. Filtro por descripcion de cuenta (parcial, sin distinción de mayúsculas)
    if (filtros?.descripcion && filtros.descripcion.trim()) {
      const d = filtros.descripcion.trim().toLowerCase();
      resultado = resultado.filter(r => (r.descripcion || '').toLowerCase().includes(d));
    }

    return resultado;
  }

  async findMovcta(movctascontablesId: number, empresaId: number) {
    return this.findOneById(this.movctaRepo, 'movctascontablesId', movctascontablesId, empresaId, 'Movimiento Cuenta');
  }

  async createMovcta(dto: any, currentUser: string) {
    return this.createEntity(this.movctaRepo, dto, currentUser);
  }

  async updateMovcta(movctascontablesId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.movctaRepo, 'movctascontablesId', movctascontablesId, empresaId, dto, currentUser, 'Movimiento Cuenta');
  }

  /**
   * Reclasificación masiva de cuenta contable:
   * Cambia TODAS las referencias de ctacontableAnterior → ctacontableNueva
   * en 6 tablas: copdadet, coctamov, cocierredet, coctasaldos,
   * tcoplantillapdadet, tcoplantillabalancesdet.
   * 
   * PRIMERO verifica que la cuenta destino exista en coctacontables.
   */
  async reclasificarCuenta(
    ctacontableAnterior: string,
    ctacontableNueva: string,
    empresaId: number,
    currentUser: string,
  ) {
    // 0. Verificar que la cuenta destino exista
    const ctaDestino = await this.ctacontablesRepo.findOne({
      where: { ctacontable: ctacontableNueva } as unknown as FindOptionsWhere<Coctacontables>,
    });
    if (!ctaDestino) {
      throw new BadRequestException(
        `La cuenta destino ${ctacontableNueva} no existe en el plan de cuentas. Créela primero.`
      );
    }

    // 1. Verificar que la cuenta origen exista
    const ctaOrigen = await this.ctacontablesRepo.findOne({
      where: { ctacontable: ctacontableAnterior } as unknown as FindOptionsWhere<Coctacontables>,
    });
    if (!ctaOrigen) {
      throw new BadRequestException(`La cuenta origen ${ctacontableAnterior} no existe.`);
    }

    // 2. Verificar que haya datos con la cuenta origen
    const countCopdadet = await this.copdadetRepo
      .createQueryBuilder('d').where('d.ctacontable = :cta', { cta: ctacontableAnterior }).getCount();
    const countMovcta = await this.movctaRepo
      .createQueryBuilder('m').where('m.ctacontable = :cta', { cta: ctacontableAnterior }).getCount();
    const countCierres = await this.cierredetRepo
      .createQueryBuilder('c').where('c.ctacontable = :cta', { cta: ctacontableAnterior }).getCount();
    const countSaldos = await this.saldosctaRepo
      .createQueryBuilder('s').where('s.ctacontable = :cta', { cta: ctacontableAnterior }).getCount();
    const countPlantPda = await this.plantillapdadetRepo
      .createQueryBuilder('p').where('p.ctacontable = :cta', { cta: ctacontableAnterior }).getCount();
    const countPlantBal = await this.plantillabalancesdetRepo
      .createQueryBuilder('b').where('b.ctacontable = :cta', { cta: ctacontableAnterior }).getCount();

    const totalRegistros = countCopdadet + countMovcta + countCierres + countSaldos + countPlantPda + countPlantBal;
    if (totalRegistros === 0) {
      throw new BadRequestException(`No se encontraron registros con la cuenta ${ctacontableAnterior}.`);
    }

    // 3. Ejecutar UPDATEs en las 6 tablas
    const resultados: Record<string, number> = {};

    // 3a. copdadet (detalle de partidas contables)
    const r1 = await this.copdadetRepo.createQueryBuilder()
      .update(Copdadet)
      .set({ ctacontable: ctacontableNueva } as any)
      .where('ctacontable = :cta', { cta: ctacontableAnterior })
      .execute();
    resultados['copdadet'] = r1.affected ?? 0;

    // 3b. coctamov (movimientos contables)
    const r2 = await this.movctaRepo.createQueryBuilder()
      .update(Coctamov)
      .set({ ctacontable: ctacontableNueva } as any)
      .where('ctacontable = :cta', { cta: ctacontableAnterior })
      .execute();
    resultados['coctamov'] = r2.affected ?? 0;

    // 3c. cocierredet (saldos de cierre)
    const r3 = await this.cierredetRepo.createQueryBuilder()
      .update(Cocierredet)
      .set({ ctacontable: ctacontableNueva } as any)
      .where('ctacontable = :cta', { cta: ctacontableAnterior })
      .execute();
    resultados['cocierredet'] = r3.affected ?? 0;

    // 3d. coctasaldos (saldos de cuenta mensuales)
    const r4 = await this.saldosctaRepo.createQueryBuilder()
      .update(Coctasaldos)
      .set({ ctacontable: ctacontableNueva } as any)
      .where('ctacontable = :cta', { cta: ctacontableAnterior })
      .execute();
    resultados['coctasaldos'] = r4.affected ?? 0;

    // 3e. tcoplantillapdadet (plantilla partida detalle)
    const r5 = await this.plantillapdadetRepo.createQueryBuilder()
      .update(Tcoplantillapdadet)
      .set({ ctacontable: ctacontableNueva } as any)
      .where('ctacontable = :cta', { cta: ctacontableAnterior })
      .execute();
    resultados['tcoplantillapdadet'] = r5.affected ?? 0;

    // 3f. tcoplantillabalancesdet (plantilla balances detalle)
    const r6 = await this.plantillabalancesdetRepo.createQueryBuilder()
      .update(Tcoplantillabalancesdet)
      .set({ ctacontable: ctacontableNueva } as any)
      .where('ctacontable = :cta', { cta: ctacontableAnterior })
      .execute();
    resultados['tcoplantillabalancesdet'] = r6.affected ?? 0;

    // 4. Resumen
    const totalAfectados = Object.values(resultados).reduce((s, v) => s + v, 0);

    return {
      message: `Cuenta ${ctacontableAnterior} reclasificada a ${ctacontableNueva} exitosamente`,
      cuentaOrigen: ctacontableAnterior,
      cuentaDestino: ctacontableNueva,
      registrosAfectados: resultados,
      totalRegistros: totalAfectados,
    };
  }

  async findAllNivelcta(empresaId: number) {
    return this.findAllByEmpresa(this.nivelctaRepo, empresaId);
  }

  async findNivelcta(nivelcontableId: number, empresaId: number) {
    return this.findOneById(this.nivelctaRepo, 'nivelcontableId', nivelcontableId, empresaId, 'Nivel Contable');
  }

  async createNivelcta(dto: any, currentUser: string) {
    return this.createEntity(this.nivelctaRepo, dto, currentUser);
  }

  async updateNivelcta(nivelcontableId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.nivelctaRepo, 'nivelcontableId', nivelcontableId, empresaId, dto, currentUser, 'Nivel Contable');
  }

  async removeNivelcta(nivelcontableId: number, empresaId: number) {
    return this.softDelete(this.nivelctaRepo, 'nivelcontableId', nivelcontableId, empresaId, 'Nivel Contable');
  }

  async findAllNaturalezacta(empresaId: number) {
    return this.findAllByEmpresa(this.naturalezactaRepo, empresaId);
  }

  async findNaturalezacta(naturalezaCtaId: number, empresaId: number) {
    return this.findOneById(this.naturalezactaRepo, 'naturalezaCtaId', naturalezaCtaId, empresaId, 'Naturaleza Cuenta');
  }

  async createNaturalezacta(dto: any, currentUser: string) {
    return this.createEntity(this.naturalezactaRepo, dto, currentUser);
  }

  async updateNaturalezacta(naturalezaCtaId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.naturalezactaRepo, 'naturalezaCtaId', naturalezaCtaId, empresaId, dto, currentUser, 'Naturaleza Cuenta');
  }

  async findAllImpuestovecinal(empresaId: number) {
    return this.findAllByEmpresa(this.impuestovecinalRepo, empresaId);
  }

  async findImpuestovecinal(impvecinalId: number, empresaId: number) {
    return this.findOneById(this.impuestovecinalRepo, 'impvecinalId', impvecinalId, empresaId, 'Impuesto Vecinal');
  }

  async createImpuestovecinal(dto: any, currentUser: string) {
    return this.createEntity(this.impuestovecinalRepo, dto, currentUser);
  }

  async updateImpuestovecinal(impvecinalId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.impuestovecinalRepo, 'impvecinalId', impvecinalId, empresaId, dto, currentUser, 'Impuesto Vecinal');
  }

  async removeImpuestovecinal(impvecinalId: number, empresaId: number) {
    return this.softDelete(this.impuestovecinalRepo, 'impvecinalId', impvecinalId, empresaId, 'Impuesto Vecinal');
  }

  async findAllTipoDocFiscal(empresaId: number) {
    return this.findAllByEmpresa(this.tipoDocFiscalRepo, empresaId);
  }

  async findTipoDocFiscal(tipodocumentofiscalId: number, empresaId: number) {
    return this.findOneById(this.tipoDocFiscalRepo, 'tipodocumentofiscalId', tipodocumentofiscalId, empresaId, 'Tipo Documento Fiscal');
  }

  async createTipoDocFiscal(dto: any, currentUser: string) {
    return this.createEntity(this.tipoDocFiscalRepo, dto, currentUser);
  }

  async updateTipoDocFiscal(tipodocumentofiscalId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.tipoDocFiscalRepo, 'tipodocumentofiscalId', tipodocumentofiscalId, empresaId, dto, currentUser, 'Tipo Documento Fiscal');
  }

  async removeTipoDocFiscal(tipodocumentofiscalId: number, empresaId: number) {
    return this.softDelete(this.tipoDocFiscalRepo, 'tipodocumentofiscalId', tipodocumentofiscalId, empresaId, 'Tipo Documento Fiscal');
  }

  // ========== Carteras Contables ==========

  async findAllCarteras(empresaId: number) {
    return this.findAllByEmpresa(this.carterasRepo, empresaId);
  }

  async findCartera(tcocarteraId: number, empresaId: number) {
    return this.findOneById(this.carterasRepo, 'tcocarteraId', tcocarteraId, empresaId, 'Cartera');
  }

  async createCartera(dto: any, currentUser: string) {
    return this.createEntity(this.carterasRepo, dto, currentUser);
  }

  async updateCartera(tcocarteraId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.carterasRepo, 'tcocarteraId', tcocarteraId, empresaId, dto, currentUser, 'Cartera');
  }

  async removeCartera(tcocarteraId: number, empresaId: number) {
    return this.softDelete(this.carterasRepo, 'tcocarteraId', tcocarteraId, empresaId, 'Cartera');
  }

  // ========== ISR (Retención en la Fuente) ==========

  async findAllIsr(empresaId: number) {
    return this.findAllByEmpresa(this.isrRepo, empresaId);
  }

  async findIsr(tcoisrId: number, empresaId: number) {
    return this.findOneById(this.isrRepo, 'tcoisrId', tcoisrId, empresaId, 'ISR');
  }

  async createIsr(dto: any, currentUser: string) {
    return this.createEntity(this.isrRepo, dto, currentUser);
  }

  async updateIsr(tcoisrId: number, empresaId: number, dto: any, currentUser: string) {
    return this.updateEntity(this.isrRepo, 'tcoisrId', tcoisrId, empresaId, dto, currentUser, 'ISR');
  }

  async removeIsr(tcoisrId: number, empresaId: number) {
    return this.softDelete(this.isrRepo, 'tcoisrId', tcoisrId, empresaId, 'ISR');
  }
}
