import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tusuarios } from './entities/usuario.entity';
import { TusuariosRol } from './entities/tusuarios-rol.entity';

/**
 * Roles con permiso de administrar cuentas contables:
 * - Editar cuentas que ya tienen historial (movimiento/cierre)
 * - Habilitar cuentas operables (sn_operable = 'S')
 */
export const ROLES_CONTABILIDAD = ['admin', 'supervisor', 'contador'];

@Injectable()
export class RolesService {
  constructor(
    @InjectRepository(Tusuarios)
    private readonly usuariosRepo: Repository<Tusuarios>,
    @InjectRepository(TusuariosRol)
    private readonly usuariosRolRepo: Repository<TusuariosRol>,
  ) {}

  /**
   * Devuelve los nombres de los roles del usuario para la empresa.
   * @param usuario `tusuarios.usuario` (PK del usuario)
   * @param empresaId Empresa activa
   */
  async getRoles(usuario: string, empresaId: number): Promise<string[]> {
    const user = await this.usuariosRepo.findOne({ where: { usuario } });
    if (!user) return [];
    const filas = await this.usuariosRolRepo.find({
      where: { usuarioId: user.usuarioId, empresaId },
    });
    return filas.map((f) => f.rol);
  }

  /** true si el usuario tiene al menos uno de los roles privilegiados de contabilidad */
  async esPrivilegiadoContabilidad(usuario: string, empresaId: number): Promise<boolean> {
    const roles = await this.getRoles(usuario, empresaId);
    return roles.some((r) => ROLES_CONTABILIDAD.includes(r));
  }
}
